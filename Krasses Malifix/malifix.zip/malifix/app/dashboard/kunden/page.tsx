import { redirect } from "next/navigation";
import { createServerSupabaseClient } from "@/lib/supabase-server";
import DashboardNav from "@/components/DashboardNav";
import TrialBanner from "@/components/TrialBanner";
import KundenList from "@/components/KundenList";

export default async function KundenPage() {
  const supabase = createServerSupabaseClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) redirect("/login");

  const { data: profile } = await supabase
    .from("users")
    .select("*")
    .eq("id", user.id)
    .single();

  const { data: kunden } = await supabase
    .from("kunden")
    .select("*")
    .eq("user_id", user.id)
    .order("name");

  return (
    <div className="flex min-h-screen bg-gray-50">
      <DashboardNav />
      <main className="flex-1 min-w-0 pb-24 md:pb-0">
        <TrialBanner
          trialEndsAt={profile?.trial_ends_at ?? null}
          isPaid={profile?.is_paid ?? false}
        />
        <div className="max-w-3xl mx-auto px-4 py-8">
          <h1 className="text-2xl font-bold text-gray-900 mb-6">Kunden</h1>
          <KundenList kunden={kunden ?? []} userId={user.id} />
        </div>
      </main>
    </div>
  );
}
