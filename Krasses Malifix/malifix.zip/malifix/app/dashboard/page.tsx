import { redirect } from "next/navigation";
import Link from "next/link";
import { createServerSupabaseClient } from "@/lib/supabase-server";
import DashboardNav from "@/components/DashboardNav";
import TrialBanner from "@/components/TrialBanner";
import { formatCurrency, formatDate } from "@/lib/utils";
import { Plus, FileText, TrendingUp, Users } from "lucide-react";
import type { Angebot } from "@/lib/supabase";

const STATUS_COLORS: Record<string, string> = {
  Entwurf: "bg-gray-100 text-gray-600",
  Gesendet: "bg-blue-50 text-blue-700",
  Beauftragt: "bg-green-50 text-green-700",
  Abgelehnt: "bg-red-50 text-red-600",
};

export default async function DashboardPage() {
  const supabase = createServerSupabaseClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login");

  const { data: profile } = await supabase
    .from("users").select("*").eq("id", user.id).single();

  const { data: angebote } = await supabase
    .from("angebote")
    .select("*, kunden(name)")
    .eq("user_id", user.id)
    .order("created_at", { ascending: false })
    .limit(10);

  const { count: kundenCount } = await supabase
    .from("kunden").select("*", { count: "exact", head: true }).eq("user_id", user.id);

  const totalUmsatz = angebote
    ?.filter((a) => a.status === "Beauftragt")
    .reduce((s, a) => s + (a.summe_brutto ?? 0), 0) ?? 0;

  return (
    <div className="flex min-h-screen bg-gray-50">
      <DashboardNav />
      <main className="flex-1 min-w-0">
        <TrialBanner trialEndsAt={profile?.trial_ends_at ?? null} isPaid={profile?.is_paid ?? false} />
        <div className="max-w-5xl mx-auto px-4 py-8 pb-24 md:pb-8">
          <div className="flex items-center justify-between mb-8">
            <div>
              <h1 className="text-2xl font-bold text-gray-900">
                Guten Tag{profile?.firma ? `, ${profile.firma}` : ""}!
              </h1>
              <p className="text-gray-500 text-sm mt-1">Hier ist deine Übersicht.</p>
            </div>
            <Link href="/angebot/neu" className="bg-[#2563EB] text-white font-semibold px-4 py-3 rounded-xl hover:bg-blue-700 transition-colors flex items-center gap-2 text-sm">
              <Plus className="w-4 h-4" />
              <span className="hidden sm:inline">Neues Angebot</span>
            </Link>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 mb-8">
            <div className="bg-white rounded-xl border border-gray-100 p-4 shadow-sm">
              <div className="flex items-center gap-2 text-gray-400 text-xs font-medium mb-2"><FileText className="w-4 h-4" />Angebote gesamt</div>
              <p className="text-2xl font-bold text-gray-900">{angebote?.length ?? 0}</p>
            </div>
            <div className="bg-white rounded-xl border border-gray-100 p-4 shadow-sm">
              <div className="flex items-center gap-2 text-gray-400 text-xs font-medium mb-2"><TrendingUp className="w-4 h-4" />Beauftragt</div>
              <p className="text-2xl font-bold text-green-600">{formatCurrency(totalUmsatz)}</p>
            </div>
            <div className="bg-white rounded-xl border border-gray-100 p-4 shadow-sm col-span-2 sm:col-span-1">
              <div className="flex items-center gap-2 text-gray-400 text-xs font-medium mb-2"><Users className="w-4 h-4" />Kunden</div>
              <p className="text-2xl font-bold text-gray-900">{kundenCount ?? 0}</p>
            </div>
          </div>

          {!profile?.stundensatz && (
            <div className="bg-blue-50 border border-blue-200 rounded-xl p-4 mb-8 flex items-start justify-between gap-4">
              <div>
                <p className="text-sm font-semibold text-blue-800">Firmendaten hinterlegen</p>
                <p className="text-sm text-blue-600 mt-0.5">Trage einmalig deinen Stundensatz und Preise ein.</p>
              </div>
              <Link href="/account" className="bg-[#2563EB] text-white text-sm font-medium px-3 py-2 rounded-lg whitespace-nowrap hover:bg-blue-700 transition-colors">Jetzt einrichten</Link>
            </div>
          )}

          <div className="bg-white rounded-xl border border-gray-100 shadow-sm overflow-hidden">
            <div className="px-5 py-4 border-b border-gray-100 flex items-center justify-between">
              <h2 className="font-semibold text-gray-900">Letzte Angebote</h2>
            </div>
            {!angebote || angebote.length === 0 ? (
              <div className="py-16 text-center">
                <FileText className="w-10 h-10 text-gray-200 mx-auto mb-3" />
                <p className="text-gray-500 text-sm">Noch keine Angebote vorhanden.</p>
                <Link href="/angebot/neu" className="inline-block mt-3 text-[#2563EB] text-sm font-medium hover:underline">Erstes Angebot erstellen →</Link>
              </div>
            ) : (
              <div className="divide-y divide-gray-50">
                {angebote.map((angebot: Angebot & { kunden?: { name: string } }) => (
                  <Link key={angebot.id} href={`/angebot/${angebot.id}`} className="flex items-center justify-between px-5 py-3.5 hover:bg-gray-50 transition-colors">
                    <div className="min-w-0">
                      <p className="font-medium text-gray-900 text-sm truncate">{angebot.titel}</p>
                      <p className="text-xs text-gray-400 mt-0.5">{(angebot as any).kunden?.name ?? "Kein Kunde"} · {formatDate(angebot.created_at)}</p>
                    </div>
                    <div className="flex items-center gap-3 shrink-0 ml-3">
                      {angebot.summe_brutto && <span className="font-semibold text-gray-900 text-sm">{formatCurrency(angebot.summe_brutto)}</span>}
                      <span className={`text-xs font-medium px-2.5 py-1 rounded-full ${STATUS_COLORS[angebot.status] ?? "bg-gray-100 text-gray-600"}`}>{angebot.status}</span>
                    </div>
                  </Link>
                ))}
              </div>
            )}
          </div>
        </div>
      </main>
    </div>
  );
}
