import Link from "next/link";
import {
  FileText,
  Smartphone,
  Zap,
  CheckCircle2,
  ArrowRight,
  MessageCircle,
} from "lucide-react";

export default function LandingPage() {
  return (
    <div className="min-h-screen bg-white">
      {/* Nav */}
      <nav className="border-b border-gray-100 bg-white/80 backdrop-blur sticky top-0 z-50">
        <div className="max-w-5xl mx-auto px-4 h-14 flex items-center justify-between">
          <span className="text-xl font-bold text-[#2563EB] tracking-tight">
            Malifix
          </span>
          <div className="flex items-center gap-3">
            <Link
              href="/login"
              className="text-sm text-gray-600 hover:text-gray-900 px-3 py-2"
            >
              Anmelden
            </Link>
            <Link
              href="/login?mode=register"
              className="bg-[#2563EB] text-white text-sm font-medium px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors"
            >
              Kostenlos testen
            </Link>
          </div>
        </div>
      </nav>

      {/* Hero */}
      <section className="max-w-5xl mx-auto px-4 pt-20 pb-24 text-center">
        <div className="inline-flex items-center gap-2 bg-blue-50 text-blue-700 text-sm font-medium px-3 py-1.5 rounded-full mb-6">
          <Zap className="w-3.5 h-3.5" />
          14 Tage kostenlos testen
        </div>

        <h1 className="text-5xl sm:text-6xl font-extrabold text-gray-900 leading-tight tracking-tight mb-6">
          Angebote mal fix
          <br />
          <span className="text-[#2563EB]">schreiben.</span>
        </h1>

        <p className="text-xl text-gray-500 max-w-xl mx-auto mb-10">
          Als Handwerker gibst du in 2 Minuten ein, was zu tun ist – Malifix
          erstellt das fertige PDF-Angebot zum Verschicken per WhatsApp.
        </p>

        <div className="flex flex-col sm:flex-row gap-3 justify-center">
          <Link
            href="/login?mode=register"
            className="bg-[#2563EB] text-white font-semibold px-8 py-4 rounded-xl text-lg hover:bg-blue-700 transition-colors flex items-center justify-center gap-2"
          >
            14 Tage kostenlos testen
            <ArrowRight className="w-5 h-5" />
          </Link>
          <a
            href="#wie-es-funktioniert"
            className="border border-gray-200 text-gray-700 font-medium px-8 py-4 rounded-xl text-lg hover:bg-gray-50 transition-colors"
          >
            Wie es funktioniert
          </a>
        </div>

        <p className="mt-4 text-sm text-gray-400">
          Keine Kreditkarte nötig · Kündigung jederzeit
        </p>
      </section>

      {/* Demo-Screenshot Placeholder */}
      <section className="max-w-4xl mx-auto px-4 pb-24">
        <div className="bg-gray-50 border border-gray-200 rounded-2xl overflow-hidden shadow-sm">
          <div className="bg-gray-100 px-4 py-3 border-b border-gray-200 flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-red-400" />
            <div className="w-3 h-3 rounded-full bg-yellow-400" />
            <div className="w-3 h-3 rounded-full bg-green-400" />
            <span className="ml-2 text-xs text-gray-400">
              malifix.de/angebot/neu
            </span>
          </div>
          <div className="p-8 space-y-4">
            <div className="bg-white rounded-xl border border-gray-200 p-4">
              <p className="text-xs text-gray-400 mb-1 font-medium uppercase tracking-wide">
                Was soll gemacht werden?
              </p>
              <p className="text-gray-700">
                Wohnzimmer 30qm Wände weiß streichen, Decke Raufaser 30qm
              </p>
            </div>
            <div className="grid grid-cols-3 gap-3 text-sm">
              <div className="bg-white rounded-lg border border-gray-200 p-3">
                <p className="text-gray-400 text-xs">Wände streichen</p>
                <p className="font-semibold text-gray-800 mt-1">
                  30 m² × 8,50 €
                </p>
                <p className="text-[#2563EB] font-bold">255,00 €</p>
              </div>
              <div className="bg-white rounded-lg border border-gray-200 p-3">
                <p className="text-gray-400 text-xs">Decke tapezieren</p>
                <p className="font-semibold text-gray-800 mt-1">
                  30 m² × 9,00 €
                </p>
                <p className="text-[#2563EB] font-bold">270,00 €</p>
              </div>
              <div className="bg-white rounded-lg border border-gray-200 p-3">
                <p className="text-gray-400 text-xs">Anfahrt</p>
                <p className="font-semibold text-gray-800 mt-1">pauschal</p>
                <p className="text-[#2563EB] font-bold">40,00 €</p>
              </div>
            </div>
            <div className="bg-[#2563EB] text-white rounded-xl p-4 flex items-center justify-between">
              <div>
                <p className="text-blue-200 text-sm">Gesamt inkl. MwSt.</p>
                <p className="text-2xl font-bold">675,55 €</p>
              </div>
              <div className="flex gap-2">
                <div className="bg-white/20 rounded-lg px-3 py-2 text-sm font-medium flex items-center gap-1">
                  <FileText className="w-4 h-4" />
                  PDF
                </div>
                <div className="bg-green-500 rounded-lg px-3 py-2 text-sm font-medium flex items-center gap-1">
                  <MessageCircle className="w-4 h-4" />
                  WhatsApp
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features */}
      <section id="wie-es-funktioniert" className="bg-gray-50 py-20">
        <div className="max-w-5xl mx-auto px-4">
          <h2 className="text-3xl font-bold text-gray-900 text-center mb-12">
            In 3 Schritten zum Angebot
          </h2>
          <div className="grid sm:grid-cols-3 gap-8">
            {[
              {
                icon: Smartphone,
                step: "1",
                title: "Eingeben",
                desc: "Tippe per Handy ein, was du machen sollst. Zum Beispiel: „Wohnzimmer 30qm Wände streichen"",
              },
              {
                icon: Zap,
                step: "2",
                title: "Berechnen",
                desc: "Malifix erkennt Räume, Tätigkeiten und m²-Angaben und berechnet den Preis mit deinen Sätzen.",
              },
              {
                icon: MessageCircle,
                step: "3",
                title: "Senden",
                desc: "PDF erstellen und direkt per WhatsApp an den Kunden schicken – fertig.",
              },
            ].map(({ icon: Icon, step, title, desc }) => (
              <div key={step} className="bg-white rounded-2xl p-6 border border-gray-100 shadow-sm">
                <div className="w-10 h-10 bg-blue-50 rounded-xl flex items-center justify-center mb-4">
                  <Icon className="w-5 h-5 text-[#2563EB]" />
                </div>
                <div className="text-xs font-bold text-blue-500 mb-1">
                  Schritt {step}
                </div>
                <h3 className="font-semibold text-gray-900 text-lg mb-2">
                  {title}
                </h3>
                <p className="text-gray-500 text-sm leading-relaxed">{desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing */}
      <section className="max-w-5xl mx-auto px-4 py-20">
        <h2 className="text-3xl font-bold text-gray-900 text-center mb-4">
          Einfache Preise
        </h2>
        <p className="text-center text-gray-500 mb-12">
          14 Tage kostenlos testen – keine Kreditkarte nötig.
        </p>
        <div className="grid sm:grid-cols-2 gap-6 max-w-2xl mx-auto">
          <div className="border border-gray-200 rounded-2xl p-6">
            <p className="text-sm font-medium text-gray-500 mb-1">Monatlich</p>
            <p className="text-4xl font-extrabold text-gray-900 mb-4">
              79€
              <span className="text-lg font-normal text-gray-400">/Monat</span>
            </p>
            {[
              "Unbegrenzte Angebote",
              "PDF-Export",
              "WhatsApp-Versand",
              "Kundenverwaltung",
            ].map((f) => (
              <div key={f} className="flex items-center gap-2 text-sm text-gray-600 mb-2">
                <CheckCircle2 className="w-4 h-4 text-green-500 shrink-0" />
                {f}
              </div>
            ))}
          </div>
          <div className="border-2 border-[#2563EB] rounded-2xl p-6 relative">
            <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-[#2563EB] text-white text-xs font-bold px-3 py-1 rounded-full">
              2 MONATE GESCHENKT
            </div>
            <p className="text-sm font-medium text-gray-500 mb-1">Jährlich</p>
            <p className="text-4xl font-extrabold text-gray-900 mb-4">
              790€
              <span className="text-lg font-normal text-gray-400">/Jahr</span>
            </p>
            {[
              "Alles aus Monatlich",
              "2 Monate gratis",
              "Prioritäts-Support",
              "Früher Zugang zu neuen Features",
            ].map((f) => (
              <div key={f} className="flex items-center gap-2 text-sm text-gray-600 mb-2">
                <CheckCircle2 className="w-4 h-4 text-[#2563EB] shrink-0" />
                {f}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="bg-[#2563EB] py-16">
        <div className="max-w-2xl mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold text-white mb-4">
            Jetzt starten – kostenlos.
          </h2>
          <p className="text-blue-200 mb-8">
            14 Tage alle Features nutzen. Danach ab 79€/Monat.
          </p>
          <Link
            href="/login?mode=register"
            className="bg-white text-[#2563EB] font-bold px-8 py-4 rounded-xl text-lg hover:bg-blue-50 transition-colors inline-flex items-center gap-2"
          >
            Kostenlos registrieren
            <ArrowRight className="w-5 h-5" />
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-gray-100 py-8 text-center text-sm text-gray-400">
        © {new Date().getFullYear()} Malifix · Angebote mal fix schreiben.
      </footer>
    </div>
  );
}
