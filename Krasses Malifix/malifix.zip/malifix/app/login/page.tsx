"use client";

import { useState, useEffect } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import Link from "next/link";
import { createClient } from "@/lib/supabase";
import { Loader2 } from "lucide-react";

export default function LoginPage() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const defaultMode = searchParams.get("mode") === "register" ? "register" : "login";

  const [mode, setMode] = useState<"login" | "register" | "magic">(defaultMode);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [firma, setFirma] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");

  const supabase = createClient();

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError("");
    setSuccess("");

    try {
      if (mode === "magic") {
        const { error } = await supabase.auth.signInWithOtp({
          email,
          options: { emailRedirectTo: `${window.location.origin}/dashboard` },
        });
        if (error) throw error;
        setSuccess("Magic Link wurde gesendet! Schau in deine Mails.");
      } else if (mode === "register") {
        const { data, error } = await supabase.auth.signUp({
          email,
          password,
          options: { emailRedirectTo: `${window.location.origin}/dashboard` },
        });
        if (error) throw error;

        if (data.user) {
          // Create profile with trial
          const trialEndsAt = new Date();
          trialEndsAt.setDate(trialEndsAt.getDate() + 14);

          await supabase.from("users").upsert({
            id: data.user.id,
            email,
            firma: firma || null,
            trial_ends_at: trialEndsAt.toISOString(),
            is_paid: false,
            anfahrt_pauschale: 40,
          });
        }

        setSuccess(
          "Registrierung erfolgreich! Schau in deine Mails zur Bestätigung."
        );
        setTimeout(() => router.push("/dashboard"), 2000);
      } else {
        const { error } = await supabase.auth.signInWithPassword({
          email,
          password,
        });
        if (error) throw error;
        router.push("/dashboard");
      }
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : "Ein Fehler ist aufgetreten.";
      if (msg.includes("Invalid login credentials")) {
        setError("E-Mail oder Passwort falsch.");
      } else if (msg.includes("User already registered")) {
        setError("Diese E-Mail ist bereits registriert. Bitte anmelden.");
      } else {
        setError(msg);
      }
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col items-center justify-center p-4">
      <div className="w-full max-w-sm">
        <Link href="/" className="block text-center mb-8">
          <span className="text-2xl font-bold text-[#2563EB] tracking-tight">
            Malifix
          </span>
        </Link>

        <div className="bg-white rounded-2xl border border-gray-200 shadow-sm p-6">
          <h1 className="text-xl font-bold text-gray-900 mb-1">
            {mode === "register"
              ? "Konto erstellen"
              : mode === "magic"
              ? "Magic Link"
              : "Willkommen zurück"}
          </h1>
          <p className="text-sm text-gray-500 mb-6">
            {mode === "register"
              ? "14 Tage kostenlos – keine Kreditkarte nötig"
              : mode === "magic"
              ? "Wir senden dir einen Link per E-Mail"
              : "Melde dich in deinem Konto an"}
          </p>

          {error && (
            <div className="bg-red-50 border border-red-200 text-red-700 text-sm rounded-lg p-3 mb-4">
              {error}
            </div>
          )}
          {success && (
            <div className="bg-green-50 border border-green-200 text-green-700 text-sm rounded-lg p-3 mb-4">
              {success}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            {mode === "register" && (
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Firmenname (optional)
                </label>
                <input
                  type="text"
                  value={firma}
                  onChange={(e) => setFirma(e.target.value)}
                  placeholder="Maler Müller GmbH"
                  className="w-full border border-gray-200 rounded-lg px-3 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
            )}

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                E-Mail-Adresse
              </label>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="hans@beispiel.de"
                className="w-full border border-gray-200 rounded-lg px-3 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            {mode !== "magic" && (
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Passwort
                </label>
                <input
                  type="password"
                  required
                  minLength={6}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Mindestens 6 Zeichen"
                  className="w-full border border-gray-200 rounded-lg px-3 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full bg-[#2563EB] text-white font-semibold py-3 rounded-lg hover:bg-blue-700 transition-colors flex items-center justify-center gap-2 disabled:opacity-60"
            >
              {loading && <Loader2 className="w-4 h-4 animate-spin" />}
              {mode === "register"
                ? "Jetzt kostenlos starten"
                : mode === "magic"
                ? "Magic Link senden"
                : "Anmelden"}
            </button>
          </form>

          <div className="mt-4 space-y-2">
            {mode !== "magic" && (
              <button
                onClick={() => setMode("magic")}
                className="w-full text-sm text-gray-500 hover:text-gray-700 py-2"
              >
                Stattdessen Magic Link nutzen
              </button>
            )}
            {mode === "magic" && (
              <button
                onClick={() => setMode("login")}
                className="w-full text-sm text-gray-500 hover:text-gray-700 py-2"
              >
                Mit Passwort anmelden
              </button>
            )}
            <div className="text-center text-sm text-gray-400">
              {mode === "register" ? (
                <>
                  Bereits registriert?{" "}
                  <button
                    onClick={() => setMode("login")}
                    className="text-[#2563EB] font-medium"
                  >
                    Anmelden
                  </button>
                </>
              ) : (
                <>
                  Noch kein Konto?{" "}
                  <button
                    onClick={() => setMode("register")}
                    className="text-[#2563EB] font-medium"
                  >
                    Registrieren
                  </button>
                </>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
