"use client";

import { useState } from "react";
import Link from "next/link";
import { CheckCircle2, Loader2, Zap } from "lucide-react";

export default function UpgradePage() {
  const [loadingMonthly, setLoadingMonthly] = useState(false);
  const [loadingYearly, setLoadingYearly] = useState(false);

  async function handleCheckout(interval: "monthly" | "yearly") {
    if (interval === "monthly") setLoadingMonthly(true);
    else setLoadingYearly(true);
    try {
      const res = await fetch("/api/checkout", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ interval }),
      });
      const { url, error } = await res.json();
      if (error) throw new Error(error);
      window.location.href = url;
    } catch {
      alert("Fehler beim Checkout. Bitte versuche es erneut.");
      setLoadingMonthly(false);
      setLoadingYearly(false);
    }
  }

  const features = [
    "Unbegrenzte Angebote",
    "Automatische PDF-Erstellung",
    "WhatsApp-Versand",
    "Kundenverwaltung",
    "Eigenes Firmenlogo im PDF",
    "Alle zukünftigen Updates",
  ];

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col items-center justify-center p-4">
      <div className="w-full max-w-lg">
        <Link href="/" className="block text-center mb-8">
          <span className="text-2xl font-bold text-[#2563EB] tracking-tight">Malifix</span>
        </Link>
        <div className="bg-white rounded-2xl border border-gray-200 shadow-sm p-6 mb-6">
          <div className="flex items-center gap-2 bg-amber-50 text-amber-700 text-sm font-medium px-3 py-2 rounded-lg mb-5 w-fit">
            <Zap className="w-4 h-4" />
            Dein 14-Tage-Test ist abgelaufen
          </div>
          <h1 className="text-2xl font-bold text-gray-900 mb-2">Weiter geht's mit Malifix</h1>
          <p className="text-gray-500 text-sm mb-6">Wähle einen Plan und schreibe in Sekunden professionelle Angebote.</p>
          <div className="space-y-3 mb-6">
            {features.map((f) => (
              <div key={f} className="flex items-center gap-2.5 text-sm text-gray-700">
                <CheckCircle2 className="w-4 h-4 text-green-500 shrink-0" />
                {f}
              </div>
            ))}
          </div>
        </div>
        <div className="grid sm:grid-cols-2 gap-4">
          <div className="bg-white rounded-2xl border border-gray-200 shadow-sm p-5">
            <p className="text-xs font-semibold text-gray-400 uppercase tracking-wide mb-1">Monatlich</p>
            <p className="text-3xl font-extrabold text-gray-900 mb-1">79€ <span className="text-base font-normal text-gray-400">/Monat</span></p>
            <p className="text-xs text-gray-400 mb-4">Jederzeit kündbar</p>
            <button onClick={() => handleCheckout("monthly")} disabled={loadingMonthly || loadingYearly} className="w-full border border-[#2563EB] text-[#2563EB] font-semibold py-3 rounded-xl hover:bg-blue-50 transition-colors flex items-center justify-center gap-2 disabled:opacity-60">
              {loadingMonthly && <Loader2 className="w-4 h-4 animate-spin" />}
              Monatlich starten
            </button>
          </div>
          <div className="bg-[#2563EB] rounded-2xl p-5 relative">
            <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-green-500 text-white text-xs font-bold px-3 py-1 rounded-full whitespace-nowrap">2 MONATE GRATIS</div>
            <p className="text-xs font-semibold text-blue-200 uppercase tracking-wide mb-1">Jährlich</p>
            <p className="text-3xl font-extrabold text-white mb-1">790€ <span className="text-base font-normal text-blue-200">/Jahr</span></p>
            <p className="text-xs text-blue-300 mb-4">= 65,83€/Monat · Du sparst 158€</p>
            <button onClick={() => handleCheckout("yearly")} disabled={loadingMonthly || loadingYearly} className="w-full bg-white text-[#2563EB] font-semibold py-3 rounded-xl hover:bg-blue-50 transition-colors flex items-center justify-center gap-2 disabled:opacity-60">
              {loadingYearly && <Loader2 className="w-4 h-4 animate-spin" />}
              Jährlich starten
            </button>
          </div>
        </div>
        <p className="text-center text-xs text-gray-400 mt-6">Sichere Zahlung über Stripe · Keine versteckten Kosten · Kündigung jederzeit möglich</p>
      </div>
    </div>
  );
}
