"use client";

import { useEffect, useState, useCallback } from "react";
import { useParams, useSearchParams, useRouter } from "next/navigation";
import Link from "next/link";
import dynamic from "next/dynamic";
import { createClient, type Angebot, type UserProfile, type Kunde } from "@/lib/supabase";
import { formatCurrency, formatDate, addDays } from "@/lib/utils";
import { ArrowLeft, Download, MessageCircle, Loader2, Check } from "lucide-react";

const PDFDownloadLink = dynamic(() => import("@react-pdf/renderer").then(m => m.PDFDownloadLink), { ssr: false });
const PdfVorlage = dynamic(() => import("@/components/PdfVorlage"), { ssr: false });

const STATUS_OPTIONS = ["Entwurf", "Gesendet", "Beauftragt", "Abgelehnt"] as const;
const STATUS_COLORS: Record<string, string> = {
  Entwurf: "bg-gray-100 text-gray-600",
  Gesendet: "bg-blue-50 text-blue-700",
  Beauftragt: "bg-green-50 text-green-700",
  Abgelehnt: "bg-red-50 text-red-600",
};

export default function AngebotDetailPage() {
  const { id } = useParams<{ id: string }>();
  const searchParams = useSearchParams();
  const router = useRouter();
  const supabase = createClient();

  const [angebot, setAngebot] = useState<Angebot | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [kunde, setKunde] = useState<Kunde | null>(null);
  const [loading, setLoading] = useState(true);
  const [statusSaving, setStatusSaving] = useState(false);
  const [pdfUrl, setPdfUrl] = useState<string | null>(null);

  const loadData = useCallback(async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) { router.push("/login"); return; }

    const [{ data: ag }, { data: pr }] = await Promise.all([
      supabase.from("angebote").select("*").eq("id", id).eq("user_id", user.id).single(),
      supabase.from("users").select("*").eq("id", user.id).single(),
    ]);

    if (!ag) { router.push("/dashboard"); return; }
    setAngebot(ag as Angebot);
    setProfile(pr as UserProfile);
    setPdfUrl(ag.pdf_url);

    if (ag.kunde_id) {
      const { data: k } = await supabase.from("kunden").select("*").eq("id", ag.kunde_id).single();
      setKunde(k);
    }
    setLoading(false);
  }, [id]);

  useEffect(() => { loadData(); }, [loadData]);

  async function updateStatus(status: string) {
    if (!angebot) return;
    setStatusSaving(true);
    await supabase.from("angebote").update({ status }).eq("id", angebot.id);
    setAngebot(prev => prev ? { ...prev, status: status as Angebot["status"] } : null);
    setStatusSaving(false);
  }

  function getWhatsAppUrl() {
    if (!angebot) return "#";
    const text = pdfUrl
      ? `Hallo${kunde?.name ? ` ${kunde.name}` : ""},\n\nanbei dein Angebot von ${profile?.firma ?? "uns"}: ${pdfUrl}`
      : `Hallo${kunde?.name ? ` ${kunde.name}` : ""},\n\nwir haben dir ein Angebot über ${formatCurrency(angebot.summe_brutto ?? 0)} erstellt. Melde dich gerne.`;
    return `https://wa.me/?text=${encodeURIComponent(text)}`;
  }

  if (loading) return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center">
      <Loader2 className="w-6 h-6 text-gray-300 animate-spin" />
    </div>
  );

  if (!angebot || !profile) return null;

  const positionen = (angebot.positionen_json ?? []) as any[];
  const mwst = Math.round(((angebot.summe_brutto ?? 0) - (angebot.summe_netto ?? 0)) * 100) / 100;
  const validBis = formatDate(addDays(new Date(angebot.created_at), 14).toISOString());

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-2xl mx-auto px-4 py-8 pb-24">
        {/* Header */}
        <div className="flex items-center gap-3 mb-6">
          <Link href="/dashboard" className="text-gray-400 hover:text-gray-600"><ArrowLeft className="w-5 h-5" /></Link>
          <div className="flex-1 min-w-0">
            <h1 className="text-xl font-bold text-gray-900 truncate">{angebot.titel}</h1>
            <p className="text-xs text-gray-400 mt-0.5">{formatDate(angebot.created_at)} · {kunde?.name ?? "Kein Kunde"}</p>
          </div>
        </div>

        {/* Status */}
        <div className="bg-white rounded-xl border border-gray-100 shadow-sm p-4 mb-5">
          <p className="text-xs font-medium text-gray-500 mb-2">Status</p>
          <div className="flex flex-wrap gap-2">
            {STATUS_OPTIONS.map(s => (
              <button
                key={s}
                onClick={() => updateStatus(s)}
                disabled={statusSaving}
                className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-all border ${angebot.status === s ? `${STATUS_COLORS[s]} border-transparent ring-2 ring-offset-1 ring-blue-400` : "border-gray-200 text-gray-500 hover:bg-gray-50"}`}
              >
                {angebot.status === s && <Check className="w-3 h-3 inline mr-1" />}
                {s}
              </button>
            ))}
          </div>
        </div>

        {/* Positions table */}
        <div className="bg-white rounded-xl border border-gray-100 shadow-sm overflow-hidden mb-5">
          <div className="px-5 py-4 border-b border-gray-100">
            <h2 className="font-semibold text-gray-900">Positionen</h2>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-gray-50">
                  <th className="text-left px-4 py-3 text-xs font-medium text-gray-500">Beschreibung</th>
                  <th className="text-right px-4 py-3 text-xs font-medium text-gray-500">Menge</th>
                  <th className="text-right px-4 py-3 text-xs font-medium text-gray-500">Preis</th>
                  <th className="text-right px-4 py-3 text-xs font-medium text-gray-500">Gesamt</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-50">
                {positionen.map((pos, idx) => (
                  <tr key={idx}>
                    <td className="px-4 py-3 text-gray-700">{pos.beschreibung}</td>
                    <td className="px-4 py-3 text-right text-gray-500">{pos.menge} {pos.einheit}</td>
                    <td className="px-4 py-3 text-right text-gray-500">{formatCurrency(pos.preis_pro_einheit)}</td>
                    <td className="px-4 py-3 text-right font-medium text-gray-700">{formatCurrency(pos.gesamt)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="border-t border-gray-100 px-5 py-4 space-y-2">
            <div className="flex justify-between text-sm text-gray-500"><span>Netto</span><span>{formatCurrency(angebot.summe_netto ?? 0)}</span></div>
            <div className="flex justify-between text-sm text-gray-500"><span>MwSt. 19%</span><span>{formatCurrency(mwst)}</span></div>
            <div className="flex justify-between font-bold text-gray-900 text-base pt-2 border-t border-gray-100">
              <span>Gesamt brutto</span><span className="text-[#2563EB]">{formatCurrency(angebot.summe_brutto ?? 0)}</span>
            </div>
          </div>
          <div className="px-5 pb-4 text-xs text-gray-400">Gültig bis: {validBis}</div>
        </div>

        {/* Actions */}
        <div className="space-y-3">
          {/* PDF download */}
          <div id="pdf-download" className="bg-white rounded-xl border border-gray-100 shadow-sm p-4">
            <p className="text-sm font-medium text-gray-700 mb-3">PDF herunterladen</p>
            <PDFDownloadLink
              document={<PdfVorlage angebot={angebot} profile={profile} kunde={kunde} />}
              fileName={`Angebot-${angebot.id.slice(0, 8)}.pdf`}
            >
              {({ loading: pdfLoading }) => (
                <button disabled={pdfLoading} className="w-full bg-gray-900 text-white font-semibold py-3 rounded-xl hover:bg-gray-800 transition-colors flex items-center justify-center gap-2 text-sm disabled:opacity-60">
                  {pdfLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Download className="w-4 h-4" />}
                  {pdfLoading ? "PDF wird erstellt..." : "PDF herunterladen"}
                </button>
              )}
            </PDFDownloadLink>
          </div>

          {/* WhatsApp */}
          <a
            href={getWhatsAppUrl()}
            target="_blank"
            rel="noopener noreferrer"
            className="w-full bg-green-500 text-white font-semibold py-3 rounded-xl hover:bg-green-600 transition-colors flex items-center justify-center gap-2 text-sm"
          >
            <MessageCircle className="w-4 h-4" />
            Per WhatsApp senden
          </a>
        </div>
      </div>
    </div>
  );
}
