import { redirect } from "next/navigation";
import Link from "next/link";
import { createServerSupabaseClient } from "@/lib/supabase-server";
import DashboardNav from "@/components/DashboardNav";
import TrialBanner from "@/components/TrialBanner";
import AngebotForm from "@/components/AngebotForm";
import { ArrowLeft } from "lucide-react";

export default async function NeuesAngebotPage() {
  const supabase = createServerSupabaseClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login");

  const { data: profile } = await supabase.from("users").select("*").eq("id", user.id).single();
  const { data: kunden } = await supabase.from("kunden").select("*").eq("user_id", user.id).order("name");

  return (
    <div className="flex min-h-screen bg-gray-50">
      <DashboardNav />
      <main className="flex-1 min-w-0">
        <TrialBanner trialEndsAt={profile?.trial_ends_at ?? null} isPaid={profile?.is_paid ?? false} />
        <div className="max-w-2xl mx-auto px-4 py-8 pb-24 md:pb-8">
          <div className="flex items-center gap-3 mb-6">
            <Link href="/dashboard" className="text-gray-400 hover:text-gray-600 transition-colors">
              <ArrowLeft className="w-5 h-5" />
            </Link>
            <h1 className="text-2xl font-bold text-gray-900">Neues Angebot</h1>
          </div>
          {profile && (
            <AngebotForm profile={profile} kunden={kunden ?? []} userId={user.id} />
          )}
        </div>
      </main>
    </div>
  );
}
