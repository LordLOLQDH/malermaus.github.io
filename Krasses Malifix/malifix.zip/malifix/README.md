# Malifix – Setup Guide

> Angebote mal fix schreiben. Handwerker → PDF → WhatsApp. In 2 Minuten.

## Voraussetzungen

- Node.js 18+
- Supabase-Konto (kostenlos)
- Stripe-Konto

---

## 1. Supabase-Projekt einrichten

1. Gehe zu [supabase.com](https://supabase.com) → "New Project"
2. Öffne den **SQL Editor** und führe `supabase/schema.sql` vollständig aus
3. Gehe zu **Storage → New Bucket**:
   - Name: `malifix_angebote`
   - Public: **Nein** (privat lassen)
4. Aktiviere im Supabase Dashboard unter **Auth → Settings** die gewünschten Auth-Provider (Email/Magic Link ist bereits aktiv)
5. Kopiere aus **Project Settings → API**:
   - `Project URL` → `NEXT_PUBLIC_SUPABASE_URL`
   - `anon public` → `NEXT_PUBLIC_SUPABASE_ANON_KEY`
   - `service_role secret` → `SUPABASE_SERVICE_ROLE_KEY`

---

## 2. Stripe einrichten

1. Gehe zu [dashboard.stripe.com](https://dashboard.stripe.com)
2. **Products → Add Product**:
   - Name: "Malifix Pro"
   - Preis 1: **79,00 € / Monat** (recurring, monthly) → Price ID kopieren
   - Preis 2: **790,00 € / Jahr** (recurring, yearly) → Price ID kopieren
3. **Developers → API Keys**: `Secret key` kopieren → `STRIPE_SECRET_KEY`
4. **Webhooks → Add Endpoint**:
   - URL: `https://DEINE-DOMAIN.vercel.app/api/stripe-webhook`
   - Events auswählen:
     - `checkout.session.completed`
     - `invoice.payment_succeeded`
     - `customer.subscription.deleted`
     - `customer.subscription.updated`
   - Webhook-Signing-Secret kopieren → `STRIPE_WEBHOOK_SECRET`
5. Gehe zu **Billing → Customer Portal → Settings** und aktiviere das Portal

---

## 3. .env.local befüllen

Kopiere `.env.example` → `.env.local` und fülle alle Werte:

```bash
cp .env.example .env.local
```

```env
NEXT_PUBLIC_SUPABASE_URL=https://xxxx.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJ...
SUPABASE_SERVICE_ROLE_KEY=eyJ...

STRIPE_SECRET_KEY=sk_live_...
STRIPE_WEBHOOK_SECRET=whsec_...
NEXT_PUBLIC_STRIPE_PRICE_MONTHLY=price_...
NEXT_PUBLIC_STRIPE_PRICE_YEARLY=price_...

NEXT_PUBLIC_APP_URL=http://localhost:3000
```

---

## 4. Lokal starten

```bash
npm install
npm run dev
```

Öffne [http://localhost:3000](http://localhost:3000)

---

## 5. Vercel Deploy

```bash
# Entweder über GitHub Push:
git init && git add . && git commit -m "init"
# → Auf vercel.com neues Projekt aus GitHub importieren

# Oder direkt:
npx vercel --prod
```

**Wichtig nach dem Deploy:**
- `NEXT_PUBLIC_APP_URL` auf deine echte Vercel-URL setzen
- Stripe Webhook-URL auf `https://DEINE-DOMAIN.vercel.app/api/stripe-webhook` aktualisieren
- Alle Env-Variablen in Vercel unter "Settings → Environment Variables" eintragen

---

## Projektstruktur

```
app/
  page.tsx              ← Landingpage
  login/page.tsx        ← Auth (Email + Magic Link)
  dashboard/page.tsx    ← Übersicht
  upgrade/page.tsx      ← Paywall
  account/page.tsx      ← Einstellungen + Billing Portal
  angebot/
    neu/page.tsx        ← Neues Angebot erstellen
    [id]/page.tsx       ← Angebot ansehen + PDF + WhatsApp
  api/
    checkout/route.ts   ← Stripe Checkout Session
    portal/route.ts     ← Stripe Billing Portal
    stripe-webhook/     ← Webhook Handler

components/
  AngebotForm.tsx       ← Eingabe + Parser + Vorschau
  PdfVorlage.tsx        ← @react-pdf/renderer Template
  TrialBanner.tsx       ← Countdown-Banner
  DashboardNav.tsx      ← Sidebar + Mobile Nav
  AccountForm.tsx       ← Firmendaten + Abo

lib/
  parser.ts             ← Text → Positionen (Regex-Parser)
  supabase.ts           ← Browser-Client + Typen
  supabase-server.ts    ← Server-Client + Service-Role
  stripe.ts             ← Stripe-Instanz
  utils.ts              ← Formatierung, Datums-Helpers

middleware.ts           ← Trial/Paywall-Check
supabase/schema.sql     ← DB-Schema + RLS
```

---

## Lokales Stripe-Webhook-Testing

```bash
# Stripe CLI installieren: https://stripe.com/docs/stripe-cli
stripe login
stripe listen --forward-to localhost:3000/api/stripe-webhook
```

Der CLI gibt dir ein temporäres `whsec_...` aus → in `.env.local` eintragen.
