-- ================================================
-- MALIFIX – Supabase Schema + RLS
-- Ausführen im Supabase SQL Editor
-- ================================================

-- USERS
create table if not exists public.users (
  id uuid primary key references auth.users(id) on delete cascade,
  email text,
  firma text,
  logo_url text,
  stundensatz numeric(10,2),
  preis_wand_qm numeric(10,2),
  preis_decke_qm numeric(10,2),
  anfahrt_pauschale numeric(10,2) default 40,
  is_paid boolean default false,
  trial_ends_at timestamptz,
  stripe_customer_id text,
  subscription_id text,
  created_at timestamptz default now()
);

alter table public.users enable row level security;

create policy "users: eigene Zeile lesen" on public.users
  for select using (auth.uid() = id);

create policy "users: eigene Zeile schreiben" on public.users
  for insert with check (auth.uid() = id);

create policy "users: eigene Zeile aktualisieren" on public.users
  for update using (auth.uid() = id);

-- KUNDEN
create table if not exists public.kunden (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references public.users(id) on delete cascade,
  name text not null,
  telefon text,
  email text,
  created_at timestamptz default now()
);

alter table public.kunden enable row level security;

create policy "kunden: nur eigene lesen" on public.kunden
  for select using (auth.uid() = user_id);

create policy "kunden: nur eigene schreiben" on public.kunden
  for insert with check (auth.uid() = user_id);

create policy "kunden: nur eigene aktualisieren" on public.kunden
  for update using (auth.uid() = user_id);

create policy "kunden: nur eigene loeschen" on public.kunden
  for delete using (auth.uid() = user_id);

-- ANGEBOTE
create table if not exists public.angebote (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references public.users(id) on delete cascade,
  kunde_id uuid references public.kunden(id) on delete set null,
  titel text not null,
  raw_text text,
  positionen_json jsonb,
  summe_netto numeric(10,2),
  summe_brutto numeric(10,2),
  status text default 'Entwurf' check (status in ('Entwurf', 'Gesendet', 'Beauftragt', 'Abgelehnt')),
  pdf_url text,
  created_at timestamptz default now()
);

alter table public.angebote enable row level security;

create policy "angebote: nur eigene lesen" on public.angebote
  for select using (auth.uid() = user_id);

create policy "angebote: nur eigene schreiben" on public.angebote
  for insert with check (auth.uid() = user_id);

create policy "angebote: nur eigene aktualisieren" on public.angebote
  for update using (auth.uid() = user_id);

create policy "angebote: nur eigene loeschen" on public.angebote
  for delete using (auth.uid() = user_id);

-- STORAGE: Bucket für PDFs
-- Erstelle in Supabase Dashboard: Storage → New Bucket → "malifix_angebote" → Private
-- Dann diese Policy:

-- insert policy für storage
-- create policy "storage: nur eigene PDFs hochladen"
-- on storage.objects for insert
-- with check (bucket_id = 'malifix_angebote' and auth.uid()::text = (storage.foldername(name))[1]);

-- select policy für storage  
-- create policy "storage: nur eigene PDFs lesen"
-- on storage.objects for select
-- using (bucket_id = 'malifix_angebote' and auth.uid()::text = (storage.foldername(name))[1]);

-- Trigger: Bei neuer Auth-User → trial setzen
create or replace function public.handle_new_user()
returns trigger as $$
begin
  insert into public.users (id, email, trial_ends_at)
  values (
    new.id,
    new.email,
    now() + interval '14 days'
  )
  on conflict (id) do nothing;
  return new;
end;
$$ language plpgsql security definer;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();
