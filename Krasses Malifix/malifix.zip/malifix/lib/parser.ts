import { Position } from "./supabase";

export type ParsedAngebot = {
  positionen: Position[];
  anfahrt: Position;
  summe_netto: number;
  summe_brutto: number;
};

type Preise = {
  preis_wand_qm: number;
  preis_decke_qm: number;
  anfahrt_pauschale: number;
  stundensatz: number;
};

// Regex-Patterns
const QM_PATTERN = /(\d+(?:[.,]\d+)?)\s*(?:qm|m²|m2)/gi;
const WAND_PATTERN = /w[äa]nd(?:e|en)?|wand/gi;
const DECKE_PATTERN = /deck(?:e|en)?/gi;
const BODEN_PATTERN = /boden|fußboden|fussboden/gi;
const RAUFASER_PATTERN = /raufaser|tapete|tapezier/gi;
const STREICHEN_PATTERN = /streich|farbe|anstrich|lackier/gi;

type RaumBlock = {
  raum: string;
  raw: string;
  qm: number[];
  hatWand: boolean;
  hatDecke: boolean;
  hatBoden: boolean;
  hatRaufaser: boolean;
  hatStreichen: boolean;
};

function extractQm(text: string): number[] {
  const matches: number[] = [];
  let m: RegExpExecArray | null;
  const regex = /(\d+(?:[.,]\d+)?)\s*(?:qm|m²|m2)/gi;
  while ((m = regex.exec(text)) !== null) {
    matches.push(parseFloat(m[1].replace(",", ".")));
  }
  return matches;
}

function splitIntoBlocks(text: string): string[] {
  // Split by comma, semicolon, newline, or common separators
  return text
    .split(/[,;\n]+/)
    .map((s) => s.trim())
    .filter((s) => s.length > 0);
}

export function parseAngebotText(
  text: string,
  preise: Preise
): ParsedAngebot {
  const positionen: Position[] = [];
  const blocks = splitIntoBlocks(text);

  for (const block of blocks) {
    const qmValues = extractQm(block);
    const hatWand = WAND_PATTERN.test(block);
    const hatDecke = DECKE_PATTERN.test(block);
    const hatBoden = BODEN_PATTERN.test(block);
    const hatRaufaser = RAUFASER_PATTERN.test(block);
    const hatStreichen = STREICHEN_PATTERN.test(block);

    // Reset regex lastIndex
    WAND_PATTERN.lastIndex = 0;
    DECKE_PATTERN.lastIndex = 0;
    BODEN_PATTERN.lastIndex = 0;
    RAUFASER_PATTERN.lastIndex = 0;
    STREICHEN_PATTERN.lastIndex = 0;

    if (qmValues.length === 0) continue;

    // Determine raum name from first word(s) before numbers
    const raumMatch = block.match(/^([^0-9,]+)/);
    const raumName = raumMatch
      ? raumMatch[1].trim().replace(/\s+/g, " ")
      : "Raum";

    let qmIndex = 0;

    if (hatWand || hatStreichen) {
      const qm = qmValues[qmIndex] ?? qmValues[0];
      if (qm) {
        const preis = preise.preis_wand_qm;
        positionen.push({
          beschreibung: `${raumName} – Wände streichen`,
          menge: qm,
          einheit: "m²",
          preis_pro_einheit: preis,
          gesamt: Math.round(qm * preis * 100) / 100,
        });
        qmIndex++;
      }
    }

    if (hatDecke || hatRaufaser) {
      const qm = qmValues[qmIndex] ?? qmValues[0];
      if (qm) {
        const preis = preise.preis_decke_qm;
        const typ = hatRaufaser ? "Raufaser tapezieren" : "Decke streichen";
        positionen.push({
          beschreibung: `${raumName} – ${typ}`,
          menge: qm,
          einheit: "m²",
          preis_pro_einheit: preis,
          gesamt: Math.round(qm * preis * 100) / 100,
        });
        qmIndex++;
      }
    }

    if (hatBoden) {
      const qm = qmValues[qmIndex] ?? qmValues[0];
      if (qm) {
        const preis = preise.stundensatz * 0.5; // Fallback: halber Stundensatz pro qm
        positionen.push({
          beschreibung: `${raumName} – Boden`,
          menge: qm,
          einheit: "m²",
          preis_pro_einheit: preis,
          gesamt: Math.round(qm * preis * 100) / 100,
        });
      }
    }

    // Fallback: hat qm aber keine bekannte Tätigkeit
    if (!hatWand && !hatDecke && !hatBoden && !hatStreichen && !hatRaufaser) {
      const qm = qmValues[0];
      positionen.push({
        beschreibung: raumName,
        menge: qm,
        einheit: "m²",
        preis_pro_einheit: preise.preis_wand_qm,
        gesamt: Math.round(qm * preise.preis_wand_qm * 100) / 100,
      });
    }
  }

  const anfahrt: Position = {
    beschreibung: "Anfahrtspauschale",
    menge: 1,
    einheit: "pauschal",
    preis_pro_einheit: preise.anfahrt_pauschale,
    gesamt: preise.anfahrt_pauschale,
  };

  const summe_netto =
    positionen.reduce((s, p) => s + p.gesamt, 0) + anfahrt.gesamt;
  const summe_brutto = Math.round(summe_netto * 1.19 * 100) / 100;

  return {
    positionen,
    anfahrt,
    summe_netto: Math.round(summe_netto * 100) / 100,
    summe_brutto,
  };
}
