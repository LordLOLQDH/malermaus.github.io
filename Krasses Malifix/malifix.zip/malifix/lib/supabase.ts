import { createBrowserClient } from "@supabase/ssr";

export function createClient() {
  return createBrowserClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
  );
}

export type UserProfile = {
  id: string;
  email: string;
  firma: string | null;
  logo_url: string | null;
  stundensatz: number | null;
  preis_wand_qm: number | null;
  preis_decke_qm: number | null;
  anfahrt_pauschale: number;
  is_paid: boolean;
  trial_ends_at: string | null;
  stripe_customer_id: string | null;
  subscription_id: string | null;
  created_at: string;
};

export type Kunde = {
  id: string;
  user_id: string;
  name: string;
  telefon: string | null;
  email: string | null;
  created_at: string;
};

export type Angebot = {
  id: string;
  user_id: string;
  kunde_id: string | null;
  titel: string;
  raw_text: string | null;
  positionen_json: Position[] | null;
  summe_netto: number | null;
  summe_brutto: number | null;
  status: "Entwurf" | "Gesendet" | "Beauftragt" | "Abgelehnt";
  pdf_url: string | null;
  created_at: string;
  kunden?: Kunde;
};

export type Position = {
  beschreibung: string;
  menge: number;
  einheit: string;
  preis_pro_einheit: number;
  gesamt: number;
};
