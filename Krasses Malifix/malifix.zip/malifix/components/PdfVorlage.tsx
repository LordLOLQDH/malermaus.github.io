import React from "react";
import { Document, Page, Text, View, StyleSheet } from "@react-pdf/renderer";
import type { Angebot, UserProfile, Kunde, Position } from "@/lib/supabase";

const styles = StyleSheet.create({
  page: { fontFamily: "Helvetica", fontSize: 10, color: "#1a1a1a", padding: 40, backgroundColor: "#ffffff" },
  header: { flexDirection: "row", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 32 },
  logo: { fontSize: 20, fontFamily: "Helvetica-Bold", color: "#2563EB" },
  firmaDaten: { textAlign: "right" },
  firmaName: { fontFamily: "Helvetica-Bold", fontSize: 11 },
  firmaDetail: { color: "#666", fontSize: 9 },
  divider: { borderBottom: "1px solid #e5e7eb", marginBottom: 20 },
  sectionTitle: { fontFamily: "Helvetica-Bold", fontSize: 9, color: "#6b7280", marginBottom: 6 },
  angebotTitle: { fontFamily: "Helvetica-Bold", fontSize: 18, color: "#111827", marginBottom: 4 },
  meta: { fontSize: 9, color: "#6b7280", marginBottom: 20 },
  kundeBox: { backgroundColor: "#f9fafb", borderRadius: 4, padding: 12, marginBottom: 24 },
  kundeName: { fontFamily: "Helvetica-Bold", fontSize: 11, marginBottom: 2 },
  kundeDetail: { fontSize: 9, color: "#6b7280" },
  table: { marginBottom: 20 },
  tableHeader: { flexDirection: "row", backgroundColor: "#f3f4f6", padding: "6 8", borderRadius: 3 },
  tableRow: { flexDirection: "row", padding: "7 8", borderBottom: "1px solid #f3f4f6" },
  tableRowEven: { backgroundColor: "#fafafa" },
  colDesc: { flex: 3 },
  colMenge: { flex: 1, textAlign: "right" },
  colPreis: { flex: 1, textAlign: "right" },
  colGesamt: { flex: 1, textAlign: "right" },
  headerText: { fontFamily: "Helvetica-Bold", fontSize: 9, color: "#374151" },
  cellText: { fontSize: 9, color: "#374151" },
  totalsBox: { marginLeft: "auto", width: 200, marginBottom: 24 },
  totalRow: { flexDirection: "row", justifyContent: "space-between", paddingVertical: 3 },
  totalLabel: { fontSize: 9, color: "#6b7280" },
  totalValue: { fontSize: 9, color: "#374151" },
  totalFinalRow: { flexDirection: "row", justifyContent: "space-between", paddingVertical: 5, borderTop: "1.5px solid #111827", marginTop: 4 },
  totalFinalLabel: { fontFamily: "Helvetica-Bold", fontSize: 11 },
  totalFinalValue: { fontFamily: "Helvetica-Bold", fontSize: 11, color: "#2563EB" },
  validBox: { backgroundColor: "#eff6ff", borderRadius: 4, padding: 10, marginBottom: 16 },
  validText: { fontSize: 9, color: "#1d4ed8" },
  footer: { position: "absolute", bottom: 30, left: 40, right: 40 },
  footerDivider: { borderBottom: "1px solid #e5e7eb", marginBottom: 8 },
  footerRow: { flexDirection: "row", justifyContent: "space-between" },
  footerText: { fontSize: 8, color: "#9ca3af" },
});

function formatEur(n: number): string {
  return new Intl.NumberFormat("de-DE", { style: "currency", currency: "EUR" }).format(n);
}
function formatDate(d: Date): string {
  return new Intl.DateTimeFormat("de-DE").format(d);
}

type Props = { angebot: Angebot; profile: UserProfile; kunde: Kunde | null; };

export default function PdfVorlage({ angebot, profile, kunde }: Props) {
  const positionen: Position[] = (angebot.positionen_json ?? []) as Position[];
  const netto = angebot.summe_netto ?? 0;
  const brutto = angebot.summe_brutto ?? 0;
  const mwst = Math.round((brutto - netto) * 100) / 100;
  const validBis = new Date();
  validBis.setDate(validBis.getDate() + 14);
  const angebotNummer = `AN-${angebot.id.slice(0, 8).toUpperCase()}`;

  return (
    <Document title={`Angebot ${angebotNummer}`} author={profile.firma ?? "Malifix"}>
      <Page size="A4" style={styles.page}>
        <View style={styles.header}>
          <Text style={styles.logo}>{profile.firma ?? "Malifix"}</Text>
          <View style={styles.firmaDaten}>
            {profile.firma && <Text style={styles.firmaName}>{profile.firma}</Text>}
            <Text style={styles.firmaDetail}>Erstellt mit Malifix</Text>
          </View>
        </View>
        <View style={styles.divider} />
        <Text style={styles.angebotTitle}>{angebot.titel}</Text>
        <Text style={styles.meta}>Angebotsnummer: {angebotNummer} · Datum: {formatDate(new Date(angebot.created_at))}</Text>
        {kunde && (
          <View style={styles.kundeBox}>
            <Text style={styles.sectionTitle}>ANGEBOT FÜR</Text>
            <Text style={styles.kundeName}>{kunde.name}</Text>
            {kunde.telefon && <Text style={styles.kundeDetail}>Tel: {kunde.telefon}</Text>}
            {kunde.email && <Text style={styles.kundeDetail}>{kunde.email}</Text>}
          </View>
        )}
        <View style={styles.table}>
          <View style={styles.tableHeader}>
            <Text style={[styles.headerText, styles.colDesc]}>Beschreibung</Text>
            <Text style={[styles.headerText, styles.colMenge]}>Menge</Text>
            <Text style={[styles.headerText, styles.colPreis]}>Preis/Einheit</Text>
            <Text style={[styles.headerText, styles.colGesamt]}>Gesamt</Text>
          </View>
          {positionen.map((pos, idx) => (
            <View key={idx} style={[styles.tableRow, idx % 2 === 1 ? styles.tableRowEven : {}]}>
              <Text style={[styles.cellText, styles.colDesc]}>{pos.beschreibung}</Text>
              <Text style={[styles.cellText, styles.colMenge]}>{pos.menge} {pos.einheit}</Text>
              <Text style={[styles.cellText, styles.colPreis]}>{formatEur(pos.preis_pro_einheit)}</Text>
              <Text style={[styles.cellText, styles.colGesamt]}>{formatEur(pos.gesamt)}</Text>
            </View>
          ))}
        </View>
        <View style={styles.totalsBox}>
          <View style={styles.totalRow}><Text style={styles.totalLabel}>Nettobetrag</Text><Text style={styles.totalValue}>{formatEur(netto)}</Text></View>
          <View style={styles.totalRow}><Text style={styles.totalLabel}>MwSt. 19%</Text><Text style={styles.totalValue}>{formatEur(mwst)}</Text></View>
          <View style={styles.totalFinalRow}><Text style={styles.totalFinalLabel}>Gesamtbetrag</Text><Text style={styles.totalFinalValue}>{formatEur(brutto)}</Text></View>
        </View>
        <View style={styles.validBox}>
          <Text style={styles.validText}>Dieses Angebot ist gültig bis {formatDate(validBis)}.</Text>
        </View>
        <View style={styles.footer} fixed>
          <View style={styles.footerDivider} />
          <View style={styles.footerRow}>
            <Text style={styles.footerText}>{profile.firma ?? ""}</Text>
            <Text style={styles.footerText}>Erstellt mit Malifix</Text>
          </View>
        </View>
      </Page>
    </Document>
  );
}
