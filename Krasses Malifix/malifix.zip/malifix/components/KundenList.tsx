"use client";

import { useState } from "react";
import { createClient, Kunde } from "@/lib/supabase";
import { Plus, Loader2, User, Trash2 } from "lucide-react";

type Props = { kunden: Kunde[]; userId: string };

export default function KundenList({ kunden: initialKunden, userId }: Props) {
  const supabase = createClient();
  const [kunden, setKunden] = useState(initialKunden);
  const [showForm, setShowForm] = useState(false);
  const [name, setName] = useState("");
  const [telefon, setTelefon] = useState("");
  const [email, setEmail] = useState("");
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");

  const inputClass =
    "w-full border border-gray-200 rounded-lg px-3 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white";

  async function handleAdd(e: React.FormEvent) {
    e.preventDefault();
    if (!name.trim()) return;
    setSaving(true);
    setError("");

    const { data, error } = await supabase
      .from("kunden")
      .insert({ user_id: userId, name: name.trim(), telefon: telefon || null, email: email || null })
      .select()
      .single();

    setSaving(false);
    if (error) {
      setError(error.message);
    } else {
      setKunden((prev) => [...prev, data].sort((a, b) => a.name.localeCompare(b.name)));
      setName("");
      setTelefon("");
      setEmail("");
      setShowForm(false);
    }
  }

  async function handleDelete(id: string) {
    if (!confirm("Kunden wirklich löschen?")) return;
    await supabase.from("kunden").delete().eq("id", id);
    setKunden((prev) => prev.filter((k) => k.id !== id));
  }

  return (
    <div className="space-y-4">
      <button
        onClick={() => setShowForm(!showForm)}
        className="flex items-center gap-2 bg-[#2563EB] text-white font-semibold px-4 py-3 rounded-xl hover:bg-blue-700 transition-colors text-sm"
      >
        <Plus className="w-4 h-4" />
        Neuen Kunden anlegen
      </button>

      {showForm && (
        <form
          onSubmit={handleAdd}
          className="bg-white rounded-xl border border-gray-100 shadow-sm p-5 space-y-3"
        >
          <h2 className="font-semibold text-gray-900">Neuer Kunde</h2>
          {error && (
            <p className="text-red-600 text-sm">{error}</p>
          )}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Name *</label>
            <input type="text" required value={name} onChange={(e) => setName(e.target.value)} className={inputClass} placeholder="Max Muster" />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Telefon</label>
              <input type="tel" value={telefon} onChange={(e) => setTelefon(e.target.value)} className={inputClass} placeholder="+49 170 …" />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">E-Mail</label>
              <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} className={inputClass} placeholder="max@…" />
            </div>
          </div>
          <div className="flex gap-3">
            <button type="submit" disabled={saving} className="flex items-center gap-2 bg-[#2563EB] text-white font-semibold px-4 py-3 rounded-lg text-sm disabled:opacity-60">
              {saving && <Loader2 className="w-4 h-4 animate-spin" />}
              Speichern
            </button>
            <button type="button" onClick={() => setShowForm(false)} className="px-4 py-3 border border-gray-200 rounded-lg text-sm text-gray-600 hover:bg-gray-50">
              Abbrechen
            </button>
          </div>
        </form>
      )}

      <div className="bg-white rounded-xl border border-gray-100 shadow-sm overflow-hidden">
        {kunden.length === 0 ? (
          <div className="py-16 text-center">
            <User className="w-10 h-10 text-gray-200 mx-auto mb-3" />
            <p className="text-gray-400">Noch keine Kunden angelegt</p>
          </div>
        ) : (
          <div className="divide-y divide-gray-50">
            {kunden.map((k) => (
              <div key={k.id} className="flex items-center gap-4 px-5 py-4">
                <div className="w-8 h-8 bg-blue-50 rounded-full flex items-center justify-center shrink-0">
                  <User className="w-4 h-4 text-[#2563EB]" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-medium text-gray-900">{k.name}</p>
                  <p className="text-sm text-gray-400">
                    {[k.telefon, k.email].filter(Boolean).join(" · ") || "Keine Kontaktdaten"}
                  </p>
                </div>
                <button
                  onClick={() => handleDelete(k.id)}
                  className="p-2 text-gray-300 hover:text-red-500 hover:bg-red-50 rounded-lg transition-colors"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
