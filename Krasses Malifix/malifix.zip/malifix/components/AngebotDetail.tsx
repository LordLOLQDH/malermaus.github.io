"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import dynamic from "next/dynamic";
import { pdf } from "@react-pdf/renderer";
import { createClient, Angebot, UserProfile, Kunde, Position } from "@/lib/supabase";
import { formatCurrency, formatDate, addDays } from "@/lib/utils";
import {
  FileText,
  MessageCircle,
  ArrowLeft,
  Loader2,
  CheckCircle2,
  ExternalLink,
} from "lucide-react";

// Dynamic import to avoid SSR issues with react-pdf
const PdfVorlage = dynamic(() => import("./PdfVorlage"), { ssr: false });

const STATUS_OPTIONS = ["Entwurf", "Gesendet", "Beauftragt", "Abgelehnt"] as const;
const STATUS_COLORS: Record<string, string> = {
  Entwurf: "bg-gray-100 text-gray-600",
  Gesendet: "bg-blue-100 text-blue-700",
  Beauftragt: "bg-green-100 text-green-700",
  Abgelehnt: "bg-red-100 text-red-600",
};

type Props = {
  angebot: Angebot & { kunden?: Kunde | null };
  profile: UserProfile;
};

export default function AngebotDetail({ angebot, profile }: Props) {
  const router = useRouter();
  const supabase = createClient();
  const positionen: Position[] = (angebot.positionen_json as Position[]) ?? [];

  const [status, setStatus] = useState(angebot.status);
  const [pdfUrl, setPdfUrl] = useState(angebot.pdf_url ?? "");
  const [generatingPdf, setGeneratingPdf] = useState(false);
  const [statusSaving, setStatusSaving] = useState(false);
  const [error, setError] = useState("");

  const kunde = angebot.kunden ?? null;
  const gueltigBis = addDays(new Date(angebot.created_at), 14);

  async function handleStatusChange(newStatus: string) {
    setStatusSaving(true);
    const { error } = await supabase
      .from("angebote")
      .update({ status: newStatus })
      .eq("id", angebot.id);

    if (!error) setStatus(newStatus as typeof status);
    setStatusSaving(false);
  }

  async function handleGeneratePdf() {
    setGeneratingPdf(true);
    setError("");

    try {
      // Dynamic import to ensure client-side only
      const { default: PdfVorlageCmp } = await import("@/components/PdfVorlage");
      const blob = await pdf(
        <PdfVorlageCmp angebot={angebot} profile={profile} kunde={kunde} />
      ).toBlob();

      const fileName = `angebot-${angebot.id}.pdf`;
      const file = new File([blob], fileName, { type: "application/pdf" });

      // Upload to Supabase Storage
      const { data: uploadData, error: uploadError } = await supabase.storage
        .from("malifix_angebote")
        .upload(`${profile.id}/${fileName}`, file, { upsert: true });

      if (uploadError) throw new Error(uploadError.message);

      // Get public URL
      const { data: urlData } = supabase.storage
        .from("malifix_angebote")
        .getPublicUrl(`${profile.id}/${fileName}`);

      const publicUrl = urlData.publicUrl;

      // Save URL to angebot
      await supabase
        .from("angebote")
        .update({ pdf_url: publicUrl })
        .eq("id", angebot.id);

      setPdfUrl(publicUrl);

      // Also trigger download
      const a = document.createElement("a");
      a.href = URL.createObjectURL(blob);
      a.download = fileName;
      a.click();
    } catch (err: unknown) {
      setError(
        "PDF-Fehler: " + (err instanceof Error ? err.message : "Unbekannt")
      );
    } finally {
      setGeneratingPdf(false);
    }
  }

  function handleWhatsApp() {
    if (!pdfUrl) {
      handleGeneratePdf().then(() => {
        if (pdfUrl) openWhatsApp();
      });
    } else {
      openWhatsApp();
    }
  }

  function openWhatsApp() {
    const text = encodeURIComponent(
      `Hallo${kunde?.name ? ` ${kunde.name}` : ""},\n\nhier ist dein Angebot von ${profile.firma ?? "uns"}:\n${pdfUrl}\n\nBei Fragen melde dich gerne!`
    );
    window.open(`https://wa.me/?text=${text}`, "_blank");
  }

  return (
    <div className="space-y-6">
      {/* Back + title */}
      <div className="flex items-center gap-4">
        <button
          onClick={() => router.back()}
          className="p-2 rounded-lg hover:bg-gray-100 transition-colors"
        >
          <ArrowLeft className="w-5 h-5 text-gray-500" />
        </button>
        <div className="flex-1 min-w-0">
          <h1 className="text-xl font-bold text-gray-900 truncate">
            {angebot.titel}
          </h1>
          <p className="text-sm text-gray-400">
            Erstellt am {formatDate(angebot.created_at)}
          </p>
        </div>
      </div>

      {error && (
        <div className="bg-red-50 border border-red-200 text-red-700 text-sm rounded-lg p-3">
          {error}
        </div>
      )}

      {/* Actions */}
      <div className="flex flex-wrap gap-3">
        <button
          onClick={handleGeneratePdf}
          disabled={generatingPdf}
          className="flex items-center gap-2 bg-[#2563EB] text-white font-semibold px-4 py-3 rounded-xl hover:bg-blue-700 transition-colors text-sm disabled:opacity-60"
        >
          {generatingPdf ? (
            <Loader2 className="w-4 h-4 animate-spin" />
          ) : (
            <FileText className="w-4 h-4" />
          )}
          {pdfUrl ? "PDF neu erstellen" : "PDF erstellen & herunterladen"}
        </button>

        {pdfUrl && (
          <>
            <a
              href={pdfUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 border border-gray-200 text-gray-700 font-medium px-4 py-3 rounded-xl hover:bg-gray-50 transition-colors text-sm"
            >
              <ExternalLink className="w-4 h-4" />
              PDF öffnen
            </a>
            <button
              onClick={handleWhatsApp}
              className="flex items-center gap-2 bg-green-500 text-white font-semibold px-4 py-3 rounded-xl hover:bg-green-600 transition-colors text-sm"
            >
              <MessageCircle className="w-4 h-4" />
              Per WhatsApp senden
            </button>
          </>
        )}

        {!pdfUrl && (
          <button
            onClick={handleWhatsApp}
            className="flex items-center gap-2 bg-green-500 text-white font-semibold px-4 py-3 rounded-xl hover:bg-green-600 transition-colors text-sm"
          >
            <MessageCircle className="w-4 h-4" />
            Per WhatsApp senden
          </button>
        )}
      </div>

      {/* Status */}
      <div className="bg-white rounded-xl border border-gray-100 shadow-sm p-5">
        <div className="flex items-center justify-between mb-3">
          <h2 className="font-semibold text-gray-900">Status</h2>
          {statusSaving && <Loader2 className="w-4 h-4 animate-spin text-gray-400" />}
        </div>
        <div className="flex flex-wrap gap-2">
          {STATUS_OPTIONS.map((s) => (
            <button
              key={s}
              onClick={() => handleStatusChange(s)}
              className={`px-3 py-1.5 rounded-full text-sm font-medium transition-colors ${
                status === s
                  ? STATUS_COLORS[s]
                  : "bg-gray-100 text-gray-400 hover:bg-gray-200"
              }`}
            >
              {s === status && <span className="mr-1">✓</span>}
              {s}
            </button>
          ))}
        </div>
      </div>

      {/* Kunde */}
      {kunde && (
        <div className="bg-white rounded-xl border border-gray-100 shadow-sm p-5">
          <h2 className="font-semibold text-gray-900 mb-3">Kunde</h2>
          <p className="font-medium text-gray-800">{kunde.name}</p>
          {kunde.telefon && (
            <p className="text-sm text-gray-500 mt-0.5">{kunde.telefon}</p>
          )}
          {kunde.email && (
            <p className="text-sm text-gray-500">{kunde.email}</p>
          )}
        </div>
      )}

      {/* Positionen */}
      <div className="bg-white rounded-xl border border-gray-100 shadow-sm overflow-hidden">
        <div className="px-5 py-4 border-b border-gray-100">
          <h2 className="font-semibold text-gray-900">Positionen</h2>
        </div>

        <div className="divide-y divide-gray-50">
          {positionen.map((pos, i) => (
            <div
              key={i}
              className="flex items-center justify-between px-5 py-3"
            >
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-gray-800 truncate">
                  {pos.beschreibung}
                </p>
                <p className="text-xs text-gray-400">
                  {pos.menge} {pos.einheit} × {formatCurrency(pos.preis_pro_einheit)}
                </p>
              </div>
              <p className="font-semibold text-gray-900 text-sm ml-4">
                {formatCurrency(pos.gesamt)}
              </p>
            </div>
          ))}
        </div>

        {/* Summen */}
        <div className="px-5 py-4 border-t border-gray-100 space-y-2">
          <div className="flex justify-between text-sm text-gray-500">
            <span>Netto</span>
            <span>{formatCurrency(angebot.summe_netto ?? 0)}</span>
          </div>
          <div className="flex justify-between text-sm text-gray-500">
            <span>MwSt. 19%</span>
            <span>
              {formatCurrency(
                Math.round(
                  ((angebot.summe_brutto ?? 0) - (angebot.summe_netto ?? 0)) *
                    100
                ) / 100
              )}
            </span>
          </div>
          <div className="flex justify-between font-bold text-base border-t border-gray-100 pt-2">
            <span>Gesamt</span>
            <span className="text-[#2563EB]">
              {formatCurrency(angebot.summe_brutto ?? 0)}
            </span>
          </div>
        </div>

        {/* Gültig bis */}
        <div className="px-5 py-3 bg-gray-50 border-t border-gray-100">
          <p className="text-xs text-gray-400">
            Angebot gültig bis{" "}
            <span className="font-medium text-gray-600">
              {formatDate(gueltigBis.toISOString())}
            </span>
          </p>
        </div>
      </div>
    </div>
  );
}
