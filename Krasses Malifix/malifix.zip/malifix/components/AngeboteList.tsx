"use client";

import { useState } from "react";
import Link from "next/link";
import { Angebot, Kunde } from "@/lib/supabase";
import { formatCurrency, formatDate } from "@/lib/utils";
import { Plus, Search } from "lucide-react";

const STATUS_OPTIONS = ["Alle", "Entwurf", "Gesendet", "Beauftragt", "Abgelehnt"];
const STATUS_COLORS: Record<string, string> = {
  Entwurf: "bg-gray-100 text-gray-600",
  Gesendet: "bg-blue-100 text-blue-700",
  Beauftragt: "bg-green-100 text-green-700",
  Abgelehnt: "bg-red-100 text-red-600",
};

type Props = {
  angebote: (Angebot & { kunden?: { name: string } | null })[];
};

export default function AngeboteList({ angebote }: Props) {
  const [filter, setFilter] = useState("Alle");
  const [search, setSearch] = useState("");

  const filtered = angebote.filter((a) => {
    const matchStatus = filter === "Alle" || a.status === filter;
    const matchSearch =
      !search ||
      a.titel.toLowerCase().includes(search.toLowerCase()) ||
      a.kunden?.name?.toLowerCase().includes(search.toLowerCase());
    return matchStatus && matchSearch;
  });

  return (
    <div className="space-y-4">
      {/* Filter & Search */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
          <input
            type="text"
            placeholder="Suchen…"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-9 pr-3 py-3 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white"
          />
        </div>
        <div className="flex gap-2 overflow-x-auto pb-1">
          {STATUS_OPTIONS.map((s) => (
            <button
              key={s}
              onClick={() => setFilter(s)}
              className={`px-3 py-2 rounded-lg text-sm font-medium whitespace-nowrap transition-colors ${
                filter === s
                  ? "bg-[#2563EB] text-white"
                  : "bg-white border border-gray-200 text-gray-600 hover:bg-gray-50"
              }`}
            >
              {s}
            </button>
          ))}
        </div>
      </div>

      {/* Table */}
      <div className="bg-white rounded-xl border border-gray-100 shadow-sm overflow-hidden">
        {filtered.length === 0 ? (
          <div className="py-16 text-center">
            <p className="text-gray-400 font-medium">Keine Angebote gefunden</p>
            <Link
              href="/angebot/neu"
              className="inline-flex items-center gap-2 mt-4 text-sm text-[#2563EB] font-medium"
            >
              <Plus className="w-4 h-4" />
              Neues Angebot erstellen
            </Link>
          </div>
        ) : (
          <div className="divide-y divide-gray-50">
            {filtered.map((a) => (
              <Link
                key={a.id}
                href={`/angebot/${a.id}`}
                className="flex items-center gap-4 px-5 py-4 hover:bg-gray-50 transition-colors"
              >
                <div className="flex-1 min-w-0">
                  <p className="font-medium text-gray-900 truncate">{a.titel}</p>
                  <p className="text-sm text-gray-400 mt-0.5">
                    {a.kunden?.name ?? "Kein Kunde"} · {formatDate(a.created_at)}
                  </p>
                </div>
                <div className="flex items-center gap-3 shrink-0">
                  <span className="font-semibold text-gray-900 text-sm">
                    {a.summe_brutto ? formatCurrency(a.summe_brutto) : "—"}
                  </span>
                  <span
                    className={`text-xs font-medium px-2 py-1 rounded-full ${
                      STATUS_COLORS[a.status] ?? STATUS_COLORS.Entwurf
                    }`}
                  >
                    {a.status}
                  </span>
                </div>
              </Link>
            ))}
          </div>
        )}
      </div>

      <p className="text-xs text-gray-400 text-center">
        {filtered.length} von {angebote.length} Angeboten
      </p>
    </div>
  );
}
