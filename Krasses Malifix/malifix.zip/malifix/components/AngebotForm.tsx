"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { createClient, type Kunde, type Position, type UserProfile } from "@/lib/supabase";
import { parseAngebotText } from "@/lib/parser";
import { formatCurrency } from "@/lib/utils";
import { Loader2, Plus, Trash2, Wand2, FileText } from "lucide-react";

type Props = { profile: UserProfile; kunden: Kunde[]; userId: string; };

export default function AngebotForm({ profile, kunden, userId }: Props) {
  const router = useRouter();
  const supabase = createClient();
  const [rawText, setRawText] = useState("");
  const [titel, setTitel] = useState("");
  const [kundeId, setKundeId] = useState("");
  const [neuerKunde, setNeuerKunde] = useState({ name: "", telefon: "", email: "" });
  const [positionen, setPositionen] = useState<Position[]>([]);
  const [anfahrt, setAnfahrt] = useState<Position | null>(null);
  const [summeNetto, setSummeNetto] = useState(0);
  const [summeBrutto, setSummeBrutto] = useState(0);
  const [parsed, setParsed] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [showNeuerKunde, setShowNeuerKunde] = useState(false);

  function recalc(pos: Position[], anf: Position | null) {
    const netto = pos.reduce((s, p) => s + p.gesamt, 0) + (anf?.gesamt ?? 0);
    setSummeNetto(Math.round(netto * 100) / 100);
    setSummeBrutto(Math.round(netto * 1.19 * 100) / 100);
  }

  function handleParse() {
    if (!rawText.trim()) return;
    const preise = {
      preis_wand_qm: profile.preis_wand_qm ?? 8.5,
      preis_decke_qm: profile.preis_decke_qm ?? 9.0,
      anfahrt_pauschale: profile.anfahrt_pauschale ?? 40,
      stundensatz: profile.stundensatz ?? 65,
    };
    const result = parseAngebotText(rawText, preise);
    setPositionen(result.positionen);
    setAnfahrt(result.anfahrt);
    recalc(result.positionen, result.anfahrt);
    setParsed(true);
    if (!titel) setTitel(rawText.slice(0, 60));
  }

  function updatePosition(idx: number, field: keyof Position, value: string) {
    const updated = positionen.map((p, i) => {
      if (i !== idx) return p;
      const newP = { ...p, [field]: (field === "beschreibung" || field === "einheit") ? value : parseFloat(value) || 0 };
      if (field === "menge" || field === "preis_pro_einheit") newP.gesamt = Math.round(newP.menge * newP.preis_pro_einheit * 100) / 100;
      return newP;
    });
    setPositionen(updated);
    recalc(updated, anfahrt);
  }

  function removePosition(idx: number) {
    const updated = positionen.filter((_, i) => i !== idx);
    setPositionen(updated);
    recalc(updated, anfahrt);
  }

  function addPosition() {
    const newPos: Position = { beschreibung: "Neue Position", menge: 1, einheit: "m2", preis_pro_einheit: profile.preis_wand_qm ?? 8.5, gesamt: profile.preis_wand_qm ?? 8.5 };
    const updated = [...positionen, newPos];
    setPositionen(updated);
    recalc(updated, anfahrt);
  }

  async function handleSave(asPdf = false) {
    setSaving(true); setError("");
    try {
      let finalKundeId = kundeId;
      if (showNeuerKunde && neuerKunde.name) {
        const { data: newKunde, error: ke } = await supabase.from("kunden").insert({ user_id: userId, name: neuerKunde.name, telefon: neuerKunde.telefon || null, email: neuerKunde.email || null }).select().single();
        if (ke) throw ke;
        finalKundeId = newKunde.id;
      }
      const allPositionen = anfahrt ? [...positionen, anfahrt] : positionen;
      const { data: angebot, error: ae } = await supabase.from("angebote").insert({ user_id: userId, kunde_id: finalKundeId || null, titel: titel || rawText.slice(0, 60), raw_text: rawText, positionen_json: allPositionen, summe_netto: summeNetto, summe_brutto: summeBrutto, status: "Entwurf" }).select().single();
      if (ae) throw ae;
      router.push(`/angebot/${angebot.id}${asPdf ? "?generate=1" : ""}`);
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : "Fehler beim Speichern.");
    } finally { setSaving(false); }
  }

  const mwst = Math.round((summeBrutto - summeNetto) * 100) / 100;

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-xl border border-gray-100 shadow-sm p-5">
        <label className="block text-sm font-semibold text-gray-900 mb-2">Was soll gemacht werden?</label>
        <p className="text-xs text-gray-400 mb-3">Tipp einfach rein was du machen sollst. Z.B. "Wohnzimmer 30qm Wände streichen, Decke Raufaser 30qm"</p>
        <textarea value={rawText} onChange={(e) => setRawText(e.target.value)} rows={4} placeholder={"Wohnzimmer 30qm Wände weiß streichen, Decke Raufaser 30qm\nBad 8qm Wände und Decke streichen"} className="w-full border border-gray-200 rounded-lg px-3 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none" />
        <button type="button" onClick={handleParse} disabled={!rawText.trim()} className="mt-3 w-full bg-[#2563EB] text-white font-semibold py-3 rounded-xl hover:bg-blue-700 transition-colors flex items-center justify-center gap-2 disabled:opacity-40">
          <Wand2 className="w-4 h-4" />Automatisch berechnen
        </button>
      </div>

      {parsed && (
        <>
          <div className="bg-white rounded-xl border border-gray-100 shadow-sm overflow-hidden">
            <div className="px-5 py-4 border-b border-gray-100 flex items-center justify-between">
              <h2 className="font-semibold text-gray-900">Positionen</h2>
              <button onClick={addPosition} className="text-[#2563EB] text-sm font-medium flex items-center gap-1 hover:underline"><Plus className="w-4 h-4" />Hinzufügen</button>
            </div>
            <div className="divide-y divide-gray-50">
              {positionen.map((pos, idx) => (
                <div key={idx} className="p-4 space-y-3">
                  <div className="flex items-start gap-2">
                    <input value={pos.beschreibung} onChange={(e) => updatePosition(idx, "beschreibung", e.target.value)} className="flex-1 border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" />
                    <button onClick={() => removePosition(idx)} className="p-2 text-gray-300 hover:text-red-400 transition-colors"><Trash2 className="w-4 h-4" /></button>
                  </div>
                  <div className="grid grid-cols-3 gap-2">
                    <div>
                      <label className="text-xs text-gray-400 mb-1 block">Menge</label>
                      <input type="number" step="0.01" value={pos.menge} onChange={(e) => updatePosition(idx, "menge", e.target.value)} className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" />
                    </div>
                    <div>
                      <label className="text-xs text-gray-400 mb-1 block">Preis/Einheit</label>
                      <input type="number" step="0.01" value={pos.preis_pro_einheit} onChange={(e) => updatePosition(idx, "preis_pro_einheit", e.target.value)} className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" />
                    </div>
                    <div>
                      <label className="text-xs text-gray-400 mb-1 block">Gesamt</label>
                      <div className="border border-gray-100 bg-gray-50 rounded-lg px-3 py-2 text-sm font-medium text-gray-700">{formatCurrency(pos.gesamt)}</div>
                    </div>
                  </div>
                </div>
              ))}
              {anfahrt && (
                <div className="px-4 py-3 flex items-center justify-between text-sm bg-gray-50">
                  <span className="text-gray-500">{anfahrt.beschreibung}</span>
                  <span className="font-medium text-gray-700">{formatCurrency(anfahrt.gesamt)}</span>
                </div>
              )}
            </div>
            <div className="border-t border-gray-100 px-5 py-4 space-y-2">
              <div className="flex justify-between text-sm text-gray-500"><span>Netto</span><span>{formatCurrency(summeNetto)}</span></div>
              <div className="flex justify-between text-sm text-gray-500"><span>MwSt. 19%</span><span>{formatCurrency(mwst)}</span></div>
              <div className="flex justify-between font-bold text-gray-900 text-base pt-1 border-t border-gray-100"><span>Gesamt brutto</span><span className="text-[#2563EB]">{formatCurrency(summeBrutto)}</span></div>
            </div>
          </div>

          <div className="bg-white rounded-xl border border-gray-100 shadow-sm p-5">
            <label className="block text-sm font-medium text-gray-700 mb-1">Angebotstitel</label>
            <input value={titel} onChange={(e) => setTitel(e.target.value)} placeholder="z.B. Wohnzimmer streichen" className="w-full border border-gray-200 rounded-lg px-3 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" />
          </div>

          <div className="bg-white rounded-xl border border-gray-100 shadow-sm p-5">
            <label className="block text-sm font-medium text-gray-700 mb-2">Kunde</label>
            {!showNeuerKunde ? (
              <div className="space-y-2">
                <select value={kundeId} onChange={(e) => setKundeId(e.target.value)} className="w-full border border-gray-200 rounded-lg px-3 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white">
                  <option value="">Kein Kunde</option>
                  {kunden.map((k) => <option key={k.id} value={k.id}>{k.name}</option>)}
                </select>
                <button onClick={() => setShowNeuerKunde(true)} className="text-[#2563EB] text-sm font-medium hover:underline flex items-center gap-1"><Plus className="w-4 h-4" />Neuen Kunden anlegen</button>
              </div>
            ) : (
              <div className="space-y-3">
                <input value={neuerKunde.name} onChange={(e) => setNeuerKunde(p => ({ ...p, name: e.target.value }))} placeholder="Name *" className="w-full border border-gray-200 rounded-lg px-3 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" />
                <input value={neuerKunde.telefon} onChange={(e) => setNeuerKunde(p => ({ ...p, telefon: e.target.value }))} placeholder="Telefon" className="w-full border border-gray-200 rounded-lg px-3 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" />
                <input value={neuerKunde.email} onChange={(e) => setNeuerKunde(p => ({ ...p, email: e.target.value }))} placeholder="E-Mail" className="w-full border border-gray-200 rounded-lg px-3 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" />
                <button onClick={() => setShowNeuerKunde(false)} className="text-gray-400 text-sm hover:text-gray-600">← Bestehenden Kunden wählen</button>
              </div>
            )}
          </div>

          {error && <p className="text-sm text-red-600 bg-red-50 rounded-lg p-3">{error}</p>}

          <div className="grid grid-cols-2 gap-3">
            <button onClick={() => handleSave(false)} disabled={saving} className="border border-gray-200 text-gray-700 font-semibold py-3 rounded-xl hover:bg-gray-50 transition-colors flex items-center justify-center gap-2 disabled:opacity-60 text-sm">
              {saving && <Loader2 className="w-4 h-4 animate-spin" />}Entwurf speichern
            </button>
            <button onClick={() => handleSave(true)} disabled={saving} className="bg-[#2563EB] text-white font-semibold py-3 rounded-xl hover:bg-blue-700 transition-colors flex items-center justify-center gap-2 disabled:opacity-60 text-sm">
              {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <FileText className="w-4 h-4" />}PDF erstellen
            </button>
          </div>
        </>
      )}
    </div>
  );
}
