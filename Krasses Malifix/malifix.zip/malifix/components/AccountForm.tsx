"use client";

import { useState } from "react";
import { createClient } from "@/lib/supabase";
import { Loader2, Check } from "lucide-react";
import type { UserProfile } from "@/lib/supabase";

type Props = { profile: UserProfile | null; userId: string; };

export default function AccountForm({ profile, userId }: Props) {
  const supabase = createClient();
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [portalLoading, setPortalLoading] = useState(false);
  const [error, setError] = useState("");
  const [form, setForm] = useState({
    firma: profile?.firma ?? "",
    stundensatz: profile?.stundensatz?.toString() ?? "",
    preis_wand_qm: profile?.preis_wand_qm?.toString() ?? "",
    preis_decke_qm: profile?.preis_decke_qm?.toString() ?? "",
    anfahrt_pauschale: profile?.anfahrt_pauschale?.toString() ?? "40",
  });

  function handleChange(e: React.ChangeEvent<HTMLInputElement>) {
    setForm((prev) => ({ ...prev, [e.target.name]: e.target.value }));
  }

  async function handleSave(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true); setError("");
    const { error } = await supabase.from("users").upsert({
      id: userId,
      firma: form.firma || null,
      stundensatz: parseFloat(form.stundensatz) || null,
      preis_wand_qm: parseFloat(form.preis_wand_qm) || null,
      preis_decke_qm: parseFloat(form.preis_decke_qm) || null,
      anfahrt_pauschale: parseFloat(form.anfahrt_pauschale) || 40,
    });
    setSaving(false);
    if (error) { setError(error.message); return; }
    setSaved(true); setTimeout(() => setSaved(false), 2000);
  }

  async function handlePortal() {
    setPortalLoading(true);
    try {
      const res = await fetch("/api/portal", { method: "POST" });
      const { url, error } = await res.json();
      if (error) throw new Error(error);
      window.location.href = url;
    } catch { alert("Fehler beim Öffnen des Kundenportals."); }
    finally { setPortalLoading(false); }
  }

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-xl border border-gray-100 shadow-sm p-5">
        <h2 className="font-semibold text-gray-900 mb-4">Firmendaten & Preise</h2>
        <form onSubmit={handleSave} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Firmenname</label>
            <input name="firma" value={form.firma} onChange={handleChange} placeholder="Maler Müller GmbH" className="w-full border border-gray-200 rounded-lg px-3 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Stundensatz (€)</label>
              <input name="stundensatz" type="number" step="0.01" value={form.stundensatz} onChange={handleChange} placeholder="65.00" className="w-full border border-gray-200 rounded-lg px-3 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Anfahrt pauschal (€)</label>
              <input name="anfahrt_pauschale" type="number" step="0.01" value={form.anfahrt_pauschale} onChange={handleChange} placeholder="40.00" className="w-full border border-gray-200 rounded-lg px-3 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Wände streichen (€/m²)</label>
              <input name="preis_wand_qm" type="number" step="0.01" value={form.preis_wand_qm} onChange={handleChange} placeholder="8.50" className="w-full border border-gray-200 rounded-lg px-3 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Decke / Raufaser (€/m²)</label>
              <input name="preis_decke_qm" type="number" step="0.01" value={form.preis_decke_qm} onChange={handleChange} placeholder="9.00" className="w-full border border-gray-200 rounded-lg px-3 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" />
            </div>
          </div>
          {error && <p className="text-sm text-red-600">{error}</p>}
          <button type="submit" disabled={saving} className="w-full bg-[#2563EB] text-white font-semibold py-3 rounded-xl hover:bg-blue-700 transition-colors flex items-center justify-center gap-2 disabled:opacity-60">
            {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : saved ? <Check className="w-4 h-4" /> : null}
            {saved ? "Gespeichert!" : "Speichern"}
          </button>
        </form>
      </div>
      <div className="bg-white rounded-xl border border-gray-100 shadow-sm p-5">
        <h2 className="font-semibold text-gray-900 mb-1">Abonnement</h2>
        <p className="text-sm text-gray-500 mb-4">{profile?.is_paid ? "Aktives Abo · Über Stripe verwalten." : "Kein aktives Abo."}</p>
        {profile?.is_paid ? (
          <button onClick={handlePortal} disabled={portalLoading} className="border border-gray-200 text-gray-700 font-medium px-4 py-3 rounded-xl hover:bg-gray-50 transition-colors flex items-center gap-2 text-sm disabled:opacity-60">
            {portalLoading && <Loader2 className="w-4 h-4 animate-spin" />}
            Abo verwalten / Kündigen
          </button>
        ) : (
          <a href="/upgrade" className="inline-block bg-[#2563EB] text-white font-semibold px-4 py-3 rounded-xl text-sm hover:bg-blue-700 transition-colors">Jetzt upgraden →</a>
        )}
      </div>
    </div>
  );
}
