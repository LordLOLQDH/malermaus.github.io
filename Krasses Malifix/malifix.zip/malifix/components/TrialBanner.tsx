"use client";

import Link from "next/link";
import { AlertTriangle } from "lucide-react";
import { daysUntilTrialEnd, formatDate } from "@/lib/utils";

type Props = {
  trialEndsAt: string | null;
  isPaid: boolean;
};

export default function TrialBanner({ trialEndsAt, isPaid }: Props) {
  if (isPaid || !trialEndsAt) return null;

  const days = daysUntilTrialEnd(trialEndsAt);

  // Only show banner if within 3 days of expiry
  if (days > 3) return null;

  const formattedDate = formatDate(trialEndsAt);

  return (
    <div className="bg-amber-50 border-b border-amber-200 px-4 py-3">
      <div className="max-w-5xl mx-auto flex items-center justify-between gap-4 flex-wrap">
        <div className="flex items-center gap-2 text-amber-800 text-sm">
          <AlertTriangle className="w-4 h-4 text-amber-500 shrink-0" />
          <span>
            Dein Malifix-Test endet am{" "}
            <span className="font-semibold">{formattedDate}</span>.{" "}
            {days <= 0
              ? "Dein Test ist abgelaufen."
              : `Noch ${days} ${days === 1 ? "Tag" : "Tage"}.`}
          </span>
        </div>
        <Link
          href="/upgrade"
          className="bg-amber-500 text-white text-sm font-semibold px-4 py-2 rounded-lg hover:bg-amber-600 transition-colors whitespace-nowrap"
        >
          Jetzt upgraden →
        </Link>
      </div>
    </div>
  );
}
